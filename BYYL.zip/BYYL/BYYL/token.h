#include <string>
#include <iostream>
#include <vector>
#include <ctype.h>
#include "wordtable.h"
#define grammar_length 35
using namespace std;
std::vector<std::string> split(std::string str, std::string pattern)
{
	std::string::size_type pos;
	std::vector<std::string> result;
	str += pattern;//��չ�ַ����Է������
	int size = str.size();

	for (int i = 0; i<size; i++)
	{
		pos = str.find(pattern, i);
		if (pos<size)
		{
			std::string s = str.substr(i, pos - i);
			result.push_back(s);
			i = pos + pattern.size() - 1;
		}
	}
	return result;
}
bool isUpper(string str)
{
	bool flag = true;
	if (str.size() <= 0) flag = false;
	for (int i = 0; i < str.size(); i++)
	{
		if (!isupper(str[i]))
		{
			flag = false;
			break;
		}
	}
	return flag;
}
typedef struct token
{
	string name;   //
	int code;
	string type;
	int addr = -1; //���ű�λ��
	int linenum;  //�к�
	token(string n, int c, int a, string t, int l){ name = n; code = c; addr = a; type = t; linenum = l; }
	token(){}
} token;
int tokennum = 0;
vector<token> tokens;  //��push_back��ʼ��
void printTokenResult2()
{
	for (int i = 0; i < tokens.size(); i++)
	{
		cout << "(" << tokens[i].name << "," << tokens[i].code << "," << tokens[i].type << "," << tokens[i].addr << "," << tokens[i].linenum << ")" << endl;
	}
}
class Grammar
{
public:
	Grammar();
	~Grammar();
	Grammar(int i,char  IN[],char ou[]){
		id = i;
		INP = IN;
		OUP = ou;
		string str = ou;
	    vector<string> ve=split(str, " ");
		for (int i = 0; i < ve.size(); i++)
		{
			if (isUpper(ve[i]))
				notEnd.push_back(ve[i]);
			else
				isEnd.push_back(ve[i]);
		}
	}
	int getid(){ return id ; }
	char  * getINP(){ return INP; }
	char *getOUP(){ return OUP; }
	bool isbelong(string str)   //�Ƿ������ս������
	{
		for (int i = 0; i < isEnd.size();i++)
		if (str == isEnd[i])
			return true;
		return false;
	}
	void print(){
		string str = "";
		for (int i = 0;; i++)
		{
			str += *(INP + i);
			if (*(INP + i) == '\0')
				break;
		}
		str +="-> ";
		for (int i = 0; *(OUP+i) != '\0'; i++)
		{
			str += *(OUP + i);
		}
		cout << str<<"\t isEnd:"; isEndprint(); cout << endl;
	}
	vector<string> getisEnd(){ return isEnd; }
private:
	int id; //�ķ����
	char * INP;  //����ʽ�󲿷�
	char * OUP;//����ʽ�Ҳ�������
	vector<string> notEnd;  //���ս��
	vector<string> isEnd; //�ս��
	void isEndprint()
	{
		for (int i = 0; i < isEnd.size(); i++)
			cout << isEnd[i] << " ";

	}
};
Grammar::Grammar()
{}
Grammar::~Grammar()
{
	/*delete OUP;*/
	//delete *Frist;
	//delete Follow;
}


#pragma region Grammar  grammar[]
Grammar  grammar[] = {
	Grammar(0, "W", "# P #"),
	Grammar(1, "P", "program id L"),     //���򣬱�ʶ����������

	Grammar(2, "L", "S ; L"),//S���  , L ������ A��ֵ��䣬B ��������ʽ��E��������ʽ
	Grammar(2, "L", "S"),
	Grammar(3, "S", "if B then S"),
	Grammar(3, "S", "if B then L else S"),
	Grammar(3, "S", "while B do S"),
	Grammar(3, "S", "begin L end"),
	Grammar(3, "S", "var D"),
	Grammar(3, "S", "?"),       //s->�� //10��
	Grammar(3, "S", "A"),
	Grammar(4, "D", "id : K ;"),        //D �������  �� id��ʶ�� ��K�������� 
	/*Grammar(4, "D", "id : K ; D"),*/
	Grammar(5, "K", "integer"),
	Grammar(5, "K", "bool"),
	Grammar(5, "K", "real"),   //156
	Grammar(6, "A", "id := E"),

	//����ʽ
	Grammar(7, "E", "E + T"),
	Grammar(7, "E", "T"),
	Grammar(7, "E", "- E"),

	Grammar(8, "B", "B or N"),    //20
	Grammar(8, "B", "N"),
	Grammar(8, "B", "not B"),      //R ���������

	/*Grammar(9, "R", "<"),
	Grammar(9, "R", ">"),
	Grammar(9, "R", "<>"),
	Grammar(9, "R", "<="),       
	Grammar(9, "R", ">="),
	Grammar(9, "R", "="),    */      

	Grammar(9, "T", "T * F"),
	Grammar(9, "T", "F"),
	Grammar(10, "F", "( E )"),    //25
	Grammar(10, "F", "id"),
	Grammar(11, "N", "N and M"),
	Grammar(11, "N", "M"),
	Grammar(12, "M", "( B )"),
	Grammar(12, "M", "id < id"),//30
	Grammar(12, "M", "id > id"),
	Grammar(12, "M", "id <> id"),
	Grammar(12, "M", "id <= id"),
	Grammar(12, "M", "id >= id"),
	Grammar(12, "M", "id = id"),

};

#pragma endregion


bool isInNotend(vector<string> s,string str)
{
	bool flag=false;
	for (int i = 0; i < s.size(); i++)
	{
		if (str == s[i])
		{
			flag = true;
			break;
		}
	}
	return flag;
}

int FindGraIndexByvec(vector<string>t) //���ݷ��ս�����ҵ���Ӧ�ķ�
{
	for (int i = 0; i < grammar_length; i++)
	{
		vector<string> s = grammar[i].getisEnd();
		if (s.size() != t.size()) continue;
		int size = s.size();
		bool flag = true;
		for (int j = 0; j < size; j++)  //t�е�Ԫ�غ�s��Ԫ��ÿ�����бȽ�
		{			
			if (!isInNotend(s, t[j])) {
				flag = false; break;  //
			}
		}
		if (!flag) continue; //����ҵ���ƥ��ģ���һ���ķ�
	    flag = true;
		for (int j = 0; j < size; j++)  //t�е�Ԫ�غ�s��Ԫ��ÿ�����бȽ�
		{
			if (!isInNotend(t, s[j])) {
				flag = false; break;  //
			}
		}
		if (!flag) continue;
		return i;
	}
	return -1;
}