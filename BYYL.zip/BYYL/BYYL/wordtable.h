#include<iostream>
#include<string>
#include<fstream>
#include <cassert>
using namespace std;
struct WordToken
{
	string name;
	int code;
};
struct WordSymble
{
	string name;   //
	int code;
	string type;
	int addr = -1; //���ű�λ��
	int linenum;  //�к�
};
struct symble
{
	int number;  //���
	string type;  //����
	string name;  //����
};
#pragma region ���ʱ�

WordToken keyword[] = { { "and", 1 }, { "begin", 2 }, { "bool", 3 }, { "do", 4 },
{ "else", 5 }, { "end", 6 }, { "false", 7 }, { "if", 8 },
{ "integer", 9 }, { "not", 10 }, { "or", 11 }, { "program", 12 }, { "real", 13 }, { "then", 14 }, { "true", 15 }, { "var", 16 }, { "while", 17 } };
WordToken operatorword[] = { { "+", 23 }, { "-", 24 }, { "*", 25 }, { "/", 26 }, { ">", 31 }, { ":=", 38 }, { "=", 32 }, { "<=", 33 }, { "<", 34 }, { "<>", 35 }, { ">", 36 }, { ">=", 37 } };
WordToken delimeter[] = { { "(", 21 }, { ")", 22 }, { ".", 27 }, { ",", 28 }, { ":", 29 }, { ";", 30 } };
#pragma endregion

int iskeyword(string s)//�ؼ���
{
	int i = 0;
	if (s != "") {
		if (((s[0] >= 'A') && (s[0] <= 'Z')) || ((s[0] >= 'a') && (s[0] <= 'z')))
		{
			while (i<17)
			{
				if (keyword[i].name == s)
				{
					return  keyword[i].code;
				}
				i++;
			}

			return 18;	//��ʶ��
		}

	}
	return -1;
}
int isoperator(string s)//���
{
	int i = 0;
	if (s != "")
	{
		while (i<12)
		{
			if (s == operatorword[i].name)
			{
				return operatorword[i].code;
				break;
			}
			i++;
		}
	}
	return -1;
}
int isdelimeter(string s)//���
{
	int i = 0;
	if (s != "")
	{
		while (i<6)
		{
			if (s == delimeter[i].name)
			{
				return delimeter[i].code;
				break;
			}
			i++;
		}
	}
	return -1;
}
int isdight(string &s, int n)//����
{
	int i = 0;
	int j = 0;
	string ss;
	bool a = true;
	string wrong;
	while (i< s.length())
	{
		if (j <= 1 && a)
		{
			if (s[i] == '.')
			{
				j++;

			}
			if (((s[i] >= 'A') && (s[i] <= 'Z')) || ((s[i] >= 'a') && (s[i] <= 'z')))
			{
				a = false;
			}
			i++;
		}
		else
		{
			for (int k = 0; k < i - 1; k++)
			{
				ss += s[k];
				s = ss;
			}
			for (int k = i - 1; k < s.length(); k++)
			{
				wrong += s[k];
			}

			break;
		}

	}

	if (j == 2 || !a)
	{
		cout << "�����к�Ϊ" << n + 1 << "   ";
		cout << "��������Ϊ" << wrong << "   ";
		cout << "��������Ϊ" << "���󵥴�" << endl;
	}
	if (j == 0)
	{
		return 19;

	}
	else if (j >= 1)
	{
		return 20;
	}
	return -1;
}
int length = 0;
extern int line = 0;
string word;
string text;
int k = 0; //wordSysmble���� 1��ʼ
int l = 0;
string alltext[100];
WordSymble wss[1000];
symble fuhaobiao[1000];
void get_token() //���ɷ��ű���token
{
	for (; alltext[line] != ""; line++)
	{
		text = alltext[line];
		length = text.length();
		for (int i = 0; i < length; i++)
		{
			if (text[i] != ' ') {
				word = "";
				if (((text[i] >= 'A') && (text[i] <= 'Z')) || ((text[i] >= 'a') && (text[i] <= 'z')))
				{
					while (((text[i] >= 'A') && (text[i] <= 'Z')) || ((text[i] >= 'a') && (text[i] <= 'z')) || ((text[i] >= 48) && (text[i] <= 57)))
					{
						word += text[i];
						i++;
					}
					i--;
					if (iskeyword(word) != -1)
					{
						if (iskeyword(word) == 18)
						{
							wss[k].name = word;
							wss[k].code = iskeyword(word);
							wss[k].type = "��ʶ��";
							wss[k].addr = l;
							wss[k].linenum = line;
							fuhaobiao[l].name = word;
							fuhaobiao[l].type = "��ʶ��";
							fuhaobiao[l].number = l;
							l++;
							k++;

						}
						else {
							wss[k].name = word;
							wss[k].code = iskeyword(word);
							wss[k].type = "�ؼ���";
							wss[k].linenum = line;
							k++;
						}
					}
				}

				else if ((text[i] >= 48) && (text[i] <= 57))
				{
					while (((text[i] >= 48) && (text[i] <= 57)) || (text[i] == '.') || ((text[i] >= 'A') && (text[i] <= 'Z')) || ((text[i] >= 'a') && (text[i] <= 'z')))
					{
						word += text[i];
						i++;
					}
					i--;
					int a = isdight(word, line);
					if (a == 19)
					{
						wss[k].name = word;
						wss[k].code = 19;
						wss[k].type = "����";
						wss[k].addr = l;
						wss[k].linenum = line;
						fuhaobiao[l].name = word;
						fuhaobiao[l].type = "����";
						fuhaobiao[l].number = l;
						l++;
						k++;
					}
					else if (a == 20)
					{
						wss[k].name = word;
						wss[k].code = 20;
						wss[k].type = "������";
						wss[k].addr = l;
						wss[k].linenum = line;
						fuhaobiao[l].name = word;
						fuhaobiao[l].type = "������";
						fuhaobiao[l].number = l;
						l++;
						k++;
					}
				}
				else
				{
					word += text[i];
					string ss = word;
					ss += text[i + 1];
					if (isoperator(ss) != -1)
					{
						word += text[i + 1];
						i = i + 1;
						wss[k].name = word;
						wss[k].code = isoperator(word);
						wss[k].type = "���";
						wss[k].linenum = line;
						k++;
					}
					else if (isdelimeter(word) != -1)
					{
						wss[k].name = word;
						wss[k].code = isdelimeter(word);
						wss[k].type = "���";
						wss[k].linenum = line;
						k++;
					}
					else if (isoperator(word) != -1)
					{
						wss[k].name = word;
						wss[k].code = isoperator(word);
						wss[k].type = "���";
						wss[k].linenum = line;
						k++;

					}
					else {
						wss[k].name = word;
						wss[k].code = 100;
						wss[k].type = "�Ƿ��ַ�";
						wss[k].linenum = line;
						k++;
					}
				}
			}
		}
	}
}
void readtext(string file)
{
	ifstream infile;
	infile.open(file.data());   //���ļ����������ļ��������� 
	assert(infile.is_open());   //��ʧ��,�����������Ϣ,����ֹ�������� 
	int i = 0;
	string s;
	while (getline(infile, s))
	{
		alltext[i] += s;

		i++;
	}
	infile.close();
}
void printReadtext(string url = "D: / a.txt")
{
	readtext(url);
	cout << "�������£�" << endl;
	for (int i = 0; alltext[i] != ""; i++)
	{
		cout << alltext[i] << endl;
	}
	cout << endl;
	cout << "������дʷ�����" << endl;
	cout << endl;
	get_token();
}
void printTokenResult()
{
	int j = 0;
	cout << endl;
	while (wss[j].name != "")
	{
		cout << "(" << wss[j].name << "," << wss[j].code << "," << wss[j].type << "," << wss[j].addr << "," << wss[j].linenum << ")" << endl;
		j++;
	}
	j = 0;
	cout << endl;
	cout << "���ű�Ϊ" << endl;
	while (fuhaobiao[j].name != "")
	{
		cout << "(" << fuhaobiao[j].number << "," << fuhaobiao[j].name << "," << fuhaobiao[j].type << ")" << endl;
		j++;
	}
	cout << endl;
}
