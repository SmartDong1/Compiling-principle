struct registers
{
	string	name;
	vector<string> Rvalue;
	registers(string n){ name = n; }
	registers(){};
	void clearPush(string n)
	{
		Rvalue.clear();
		Rvalue.push_back(n);
	}
	bool isinReg(string n)
	{
		bool flag = false;
		for (int i = 0; i < Rvalue.size(); i++)
		{
			if (Rvalue[i] == n)
				flag = true;
		}
		return flag;
	}
};
vector<registers> regs = { registers("AX"), registers("BX"), registers("DX") };
registers findreg(string arg,int &index)
{
	
	//����ҵ�ԭ���е�
	for (int i = 0; i < regs.size(); i++)
	{
		if (regs[i].isinReg(arg))
		{
			index = i;
			return regs[i];
		}
	}
	//û���򷵻ؿռĴ���
	for (int i = 0; i < regs.size(); i++)
	{
		if (regs[i].Rvalue.size()==0)
		{
			index = i;
			return regs[i];
		}
	}
	
	//���û�пյ�,emmm.... ��������������(��)
	return NULL;
}
bool isExistRvalue(string arg)
{
	for (int i = 0; i < regs.size(); i++)
	{		
			if (regs[i].isinReg(arg))
				return true;		
	}
	return false;
}
