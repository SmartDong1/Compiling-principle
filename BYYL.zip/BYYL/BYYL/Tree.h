#include <iostream>
#include <crtdbg.h>
#include <cstring>
#include <assert.h>
#include "token.h"
#include "GenStruct.h"
using namespace std;

typedef token DataType;
struct TreeNode
{
	TreeNode()
	{
		fristnextquad = getNextquad();
		nextquad = getNextquad();
		value = data.name;
		sibling = NULL;
		child = NULL;
	}
	DataType data;
	TreeNode * sibling; //���ֵܽ��
	TreeNode * child;   //���ӽ��
	string nextquad;
	string fristnextquad;
	string value;  //������ֵ,����ʽ����Ԫ����T1��T2
	vector<string>nextlist;
	vector<string>truelist; //����ڼ�
	vector<string>falselist; //���ڼ�
};
typedef TreeNode *DataStack; // �洢����Ϊ TreeNode*
//��ͨ��
class Tree
{
private:
	TreeNode *root=NULL;
	Tree(const Tree &) {}//��ֹ�������� �� ��ֵ
	/*Tree & operator=(const Tree &) { return *this; }*/
public:
	Tree(const DataType &data);
	Tree(){}
	~Tree();
	const TreeNode * GetRoot()const { return root; }
	TreeNode * GetRoot() { return root; }
	void Init(const DataType &data);
	void Destroy(TreeNode * p);//ɾ�������
	void DestroySub(TreeNode * p);//ɾ���ӽ��;
	TreeNode * InsertChild(TreeNode *p, DataType data);
	void InsertAllChild(TreeNode *p, vector<DataType> data);
	TreeNode * InsertSibling(TreeNode *p, DataType data);
	void Print(const TreeNode * p); //�������
	TreeNode *  Find(TreeNode * p, DataType data);//Ѱ��data���ز����ؽ��
	void Print2(); //�ǵݹ��������
	void CreateTree(TreeNode *t){
		root = t;
	}
};
//������ջ
class Stack
{
private:
	struct Node
	{
		DataStack data;
		Node *next;
	};
	Node * head;
	void Init()
	{
		head = NULL;
	}
	void Destroy()
	{
		for (Node* p = head; p != NULL;)
		{
			Node *pTemp = p->next;
			delete p;
			p = pTemp;
		}
		head = NULL;
	}
public:
	Stack()
	{
		Init();
	}
	~Stack()
	{
		Destroy();
	}
	void Push(DataStack  data)
	{
		Node *p = new Node;
		p->data = data;
		p->next = head;
		head = p;
	}
	DataStack Pop()
	{
		if (head == NULL)
		{
			return NULL;
		}
		Node *p = head;
		DataStack temp = p->data;
		head = head->next;
		delete p;
		p = NULL;
		return temp;
	}
	int Getlenth()
	{
		int n = 0;
		for (Node *p = head; p != NULL; p = p->next)
		{
			++n;
		}
		return n;
	}
	DataStack Getop()
	{
		if (head == NULL)
		{
			return NULL;
		}
		return head->data;
	}
	bool Empty()
	{
		return (head == NULL);
	}
};
//��ͨ������ʵ��
#pragma region classTreeMethod
Tree::Tree(const DataType &data)
{
	Init(data);
}
Tree::~Tree()
{
	Destroy(root);
}
void Tree::Init(const DataType &data)
{
	root = new TreeNode;
	root->child = NULL;
	root->sibling = NULL;
	root->data = data;
}
void Tree::Destroy(TreeNode * p)
{
	if (p == NULL)
	{
		return;
	}
	Destroy(p->sibling);
	Destroy(p->child);
	delete p;
	p = NULL;
}
void Tree::DestroySub(TreeNode * p)
{
	if (p->child)
	{
		Destroy(p->child);
		p->child = NULL;
	}
}
TreeNode * Tree::InsertChild(TreeNode * p, DataType data)
{
	if (p->child)
	{
		return p->child; //�����ӽ��
	}
	TreeNode *pNew = new TreeNode;
	pNew->data = data;
	p->child = pNew;
	return pNew;
}
void Tree::InsertAllChild(TreeNode * p, vector<DataType> data)
{
	for (int i = data.size() - 1; i >= 0; i--){
		if (!p->child)
		{
			TreeNode *pNew = new TreeNode;
			pNew->data = data[i];
			p->child = pNew;
			continue;
		}
		TreeNode *n = p->child;
		while (n->sibling)
		{
			n = n->sibling;
		}
		InsertSibling(n, data[i]);
	}
}
TreeNode * Tree::InsertSibling(TreeNode * p, DataType data)
{
	if (p->sibling)
	{
		return p->sibling;//�����ֵܽ��
	}
	TreeNode *pNew = new TreeNode;
	pNew->data = data;
	p->sibling = pNew;
	return pNew;
}
//�������
void  Tree::Print(const TreeNode * p)
{
	if (p == NULL)
	{
		return;
	}
	cout << p->data.name << endl;
	Print(p->child);
	Print(p->sibling);
}
//Ѱ��data�����ؽ��
TreeNode *  Tree::Find(TreeNode * p, DataType data)
{
	if (p == NULL)
		return NULL;
	if (p->data.code == data.code)
	{
		return p;
	}
	TreeNode *pFind = Find(p->child, data);
	if (pFind != NULL)
	{
		return pFind;
	}

	return Find(p->sibling, data);
}
//�ǵݹ��������
void Tree::Print2()
{
	TreeNode *p = GetRoot();
	if (p == NULL)
	{
		return;
	}
	Stack stack;

	while ((p != NULL) || (!stack.Empty()))
	{
		if (p != NULL)
		{
			cout << p->data.name << endl;
			stack.Push(p);
			p = p->child;
		}
		else
		{
			p = stack.Pop();
			p = p->sibling;
		}
	}
}
void AoRuBiao(const TreeNode *p, int depth)
{
	if (p == NULL)
	{
		return;
	}
	for (int i = 0; i < depth; ++i)
	{
		cout << " ";
	}
	cout << p->data.name;
	for (int i = 0; i < 10 - depth; ++i)
	{
		cout << " - ";
	}
	cout << endl;
	AoRuBiao(p->child, depth + 1);
	AoRuBiao(p->sibling, depth);
}
void GuangYiBiao(const TreeNode *p)
{
	if (p == NULL)
	{
		return;
	}
	cout << p->data.name;
	if (p->child)
	{
		cout << "(";
	}
	GuangYiBiao(p->child);
	if (p->child)
	{
		cout << ")";
	}
	if (p->sibling)
	{
		cout << ",";
	}
	GuangYiBiao(p->sibling);
}

//void main()
//{
//	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
//
//	Tree tree(10);
//
//	//Stack s;
//	//s.Push(tree.GetRoot());
//	//cout << s.Getop()->data;
//
//	TreeNode * p11 = tree.InsertChild(tree.GetRoot(), 11);
//	TreeNode * p12 = tree.InsertSibling(p11, 12);
//	TreeNode * p13 = tree.InsertSibling(p12, 13);
//
//	TreeNode * p111 = tree.InsertChild(p11, 111);
//	TreeNode * p112 = tree.InsertSibling(p111, 112);
//
//	TreeNode * p121 = tree.InsertChild(p12, 121);
//	TreeNode * p122 = tree.InsertSibling(p121, 122);
//
//	tree.Print(tree.GetRoot());
//	//tree.DestroySub(p12);
//	//tree.Print(tree.GetRoot());
//	cout << "\n\nSearch p12" << endl;
//	TreeNode * temp = tree.Find(tree.GetRoot(), 12);
//	if (temp != NULL)
//	{
//		cout << temp->child->data << endl;
//		cout << temp->sibling->data << endl;
//	}
//
//	cout << "\n\nAoRuBiao " << endl;
//	AoRuBiao(tree.GetRoot(), 1);
//
//	cout << "\nGuangYiBiao" << endl;
//	GuangYiBiao(tree.GetRoot());
//
//	cout << "\n\n�ǵݹ����" << endl;
//	tree.Print2();
//
//	system("pause");
//}
TreeNode * InsertSibling(TreeNode * p, DataType data)
{
	if (p->sibling)
	{
		return p->sibling;//�����ֵܽ��
	}
	TreeNode *pNew = new TreeNode;
	pNew->data = data;
	p->sibling = pNew;
	return pNew;
}

//void InsertAllChild(TreeNode * p, DataType data)
//{
//		if (!p->child)
//		{
//			TreeNode *pNew = new TreeNode;
//			pNew->data = data;
//			p->child = pNew;
//		}
//		TreeNode *n = p->child;
//		while (n->sibling)
//		{
//			n = n->sibling;
//		}
//		InsertSibling(n, data);
//	
//}
//void InsertAllChild(TreeNode * p, TreeNode data)
//{
//	
//		if (!p->child)
//		{
//			p->child = &data;
//		}
//		TreeNode *n = p->child;
//		while (n->sibling)
//		{
//			n = n->sibling;
//		}
//		InsertSibling(n, data);
//	
//}
TreeNode * InsertSibling(TreeNode * p, TreeNode * data)
{
	if (p->sibling)
	{
		return p->sibling;//�����ֵܽ��
	}
	p->sibling = data;
	return p->sibling;
}
TreeNode * InsertAllChild(TreeNode * p, vector<TreeNode> data)
{

	for (int i = data.size() - 1; i >= 0; i--)
	{
		TreeNode *Newtemp = new TreeNode;
		Newtemp->data = data[i].data;
		Newtemp->child = data[i].child;
		Newtemp->sibling = data[i].sibling;
		if (!p->child) //����޺���
		{
			p->child = Newtemp;
			continue;
		}
		TreeNode *n = p->child;
		while (n->sibling)
		{
			n = n->sibling;
		}
		n = InsertSibling(n, Newtemp);
		n = n->sibling;
	}
	return p;
}

TreeNode *CreateTreeNode(DataType data)
{
	TreeNode *pNew = new TreeNode;
	pNew->data = data;
	return pNew;
}
TreeNode *CreateTreeNode(string data)
{
	TreeNode *pNew = new TreeNode;
	DataType token(data, 0, -1, "���ս��", 0);
	pNew->data = token;
	return pNew;
}
#pragma endregion


void GrammarAction(TreeNode  *pNew, vector<TreeNode> pushend,int index) //���嶯�� index�������ķ����� pushend�����������  pNew �����
{
	
	/*for (int i = 0; i < pushend.size(); i++){
		if (pushend[i].data.name == ";")
		{
			vector<TreeNode>::iterator it = pushend.begin() + i;
			pushend.erase(it);
		}
	}*/
	string value1;
	string backpatchfalse;
	switch (index)
	{
#pragma region ...
	case 0:
		pNew->nextlist = pushend[1].nextlist;
		break;
	case 1:
		pNew->nextlist = pushend[0].nextlist;
		break;
	case 2:
		pNew->nextlist = pushend[0].nextlist;
		break;
	case 3:
		pNew->nextlist = pushend[0].nextlist;
		break;
		//S
	case 4: //if B then S
		backpatch(pushend[pushend.size() - 2].truelist, pushend[pushend.size() - 2].nextquad);
		pNew->nextlist = merge(pushend[0].nextlist, pushend[pushend.size() - 2].falselist);
		break;
	case 5://if B then L else S,then Ҫ��ת�� else����
		
		int2str(stoi(pushend[2].nextquad)+1,backpatchfalse);
		backpatch(pushend[pushend.size() - 2].truelist, pushend[pushend.size() - 2].nextquad);
		backpatch(pushend[pushend.size() - 2].falselist, backpatchfalse);
		//backpatch(pushend[pushend.size() - 2].falselist, pushend[0].fristnextquad);
		pNew->nextlist = merge(pushend[0].nextlist, pushend[pushend.size() - 2].falselist);
		CreateGen("j", "0", "0", pushend[0].nextquad);
		pNew->nextquad = getNextquad();
		//��getnextquad�Ĳ���ʽ���뵽pushend[2].nextquad ,��13���뵽7����8
		InsertGentoIndex(getNextquad(), pushend[2].nextquad);
		break;
	case 6://s->while B do S
	/*	backpatch(pushend[0].nextlist,pushend[2].fristnextquad);*/
		backpatch(pushend[2].truelist, pushend[2].nextquad);
		pNew->nextlist = pushend[2].falselist;
		CreateGen("j", "0", "0", pushend[2].fristnextquad);
		pNew->nextquad = getNextquad();
		backpatch(pushend[2].falselist, getNextquad());
		break;
	case 7://begin  S end
		pNew->nextlist = pushend[1].nextlist;
		break;
	case 8://var D
		break;
	case 9:// ?
		break;
	case 10://S->A
		break;


	case 11: //D:->id:K
		break;
	case 12://k->integer
		break;
	case 13://k->integer
		break;
	case 14://k->integer
		break;
	case 15://A-> id:=E
		CreateGen(pushend[1].data.name, pushend[0].value, "0", pushend[2].data.name);
		pNew->nextquad = getNextquad();
		break;
	case 16://E->E+T
		 value1 = NewTempStruct();
		CreateGen("+", pushend[2].value, pushend[0].value, value1);
		pNew->value = value1;
		pNew->nextquad = getNextquad();
		break;
	case 17:
		pNew->value = pushend[0].value;
		break;
#pragma endregion
	case 18: //E->-E
		value1 = NewTempStruct();
		CreateGen("-","0", pushend[0].value, value1);
		pNew->nextquad = getNextquad();
		pNew->value = value1;
		break;
	case 19://B-> B or N
		backpatch(pushend[pushend.size() - 1].falselist, pushend[pushend.size() - 1].nextquad);
		pNew->truelist = merge(pushend[pushend.size() - 1].truelist, pushend[0].truelist);
		pNew->falselist = pushend[0].falselist;
		pNew->fristnextquad = pushend[2].fristnextquad;
		break;
	case 20://B->N
		pNew->falselist = pushend[0].falselist;
		pNew->truelist = pushend[0].truelist;
		pNew->value = pushend[0].value;
		break;
	case 21://B->not B
		pNew->falselist = pushend[0].truelist;
		pNew->truelist = pushend[0].falselist;
		pNew->value = pushend[0].value;
		break;
	case 22: //T->T*F
		value1 = NewTempStruct();
		CreateGen("*", pushend[2].value, pushend[0].value, value1);
		pNew->value = value1;
		pNew->nextquad = getNextquad();
		break;
	case 23://T->F
		pNew->falselist = pushend[0].falselist;
		pNew->truelist = pushend[0].truelist;
		pNew->value = pushend[0].value;
		break;
	case 24://F->(E)
		pNew->falselist = pushend[1].falselist;
		pNew->truelist = pushend[1].truelist;
		pNew->value = pushend[1].value;
		break;
	case 25://F->id
		pNew->value = pushend[0].data.name;
		break;
		//	Grammar(11, "N", "N and M"),
		//	Grammar(11, "N", "M"),
		//	Grammar(12, "M", "( B )"),
		//	Grammar(12, "M", "id < id"),//30
		//	Grammar(12, "M", "id > id"),
		//	Grammar(12, "M", "id <> id"),
		//	Grammar(12, "M", "id <= id"),
		//	Grammar(12, "M", "id >= id"),
		//	Grammar(12, "M", "id = id"),
	case 26://N->N and M
		backpatch(pushend[pushend.size() - 1].truelist, pushend[pushend.size() - 1].nextquad);
		pNew->falselist = merge(pushend[pushend.size() - 1].falselist, pushend[0].falselist);
		pNew->truelist = pushend[0].truelist;
		pNew->fristnextquad = pushend[2].fristnextquad;
		break;
	case 27:
		pNew->falselist = pushend[0].falselist;
		pNew->truelist = pushend[0].truelist;
		pNew->value = pushend[0].value;
		break;
	case 28: //M->(B)
		pNew->falselist = pushend[1].falselist;
		pNew->truelist = pushend[1].truelist;
		pNew->value = pushend[1].value;
		break;
	case 29: //M->id <id
	case 30: //>
	case 31: //<>
	case 32: //<=
	case 33://>=
	case 34://=
		string s1;
		int2str(stoi(getNextquad())+ 1, s1);
		pNew->truelist.push_back(getNextquad());
		pNew->falselist.push_back(s1);
		CreateGen("j"+pushend[1].data.name,pushend[2].data.name,pushend[0].data.name,"0");
		CreateGen("j","0", "0", "0");
		pNew->nextquad = getNextquad();
		break;
	}
}