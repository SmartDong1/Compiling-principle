//#include <string>
//#include <iostream>
//#include "token.h"
//using namespace std;
//
//token getNexttoken()
//{
//	return token();
//}
//token setNexttoken(int)
//{
//	return token();
//}
//bool P(token to)  // P-> program id L
//{
//	if (to.name == "program")
//	{
//		token t = getNexttoken();
//		if (isid(t))
//		{
//			token t = getNexttoken();
//			bool  isL = L(t);
//			if (isL)
//				return true;
//			return false;  //�޳�����
//		}
//		return false;   //�ޱ�ʶ��
//	}
//	else
//		return false;   //��program
//}
//bool isid(token t)
//{
//	
//	if (t.type == "��ʶ��")
//		return true;
//	return false;
//}
//bool S(token t1)
//{
//	if (t1.type == "��ʶ��")  //id := E  
//	{
//		token t = getNexttoken();
//		if (t.name != ":=")
//			return false;
//		token t = getNexttoken();
//		if( !E(t)) return false;
//		token t = getNexttoken();
//		if (t.name == ";")
//			return true;
//	}
//	else if (t1.name == "if")
//	{
//		token t = getNexttoken();
//		if(!ifs(t))return false;
//	}
//	else if (t1.name == "while")
//	{
//		token t = getNexttoken();
//		if(!whiles(t)) return false;
//		token t = getNexttoken();
//		if (t.name == ";")
//			return true;
//	}
//	else if (t1.name == "var")
//	{
//		token t = getNexttoken();
//		if (!var(t)) return false;
//		token t = getNexttoken();
//		if (t.name == ";")
//			return true;
//	}
//	else if (t1.name == ";")
//	{
//		return true;
//	}
//	else   //S->nil
//		return true;
//}
//bool ifs(token t)
//{
//	if (E(t))
//	{
//		token t = getNexttoken();
//		if (t.name != "then") return false;//��if �� then
//		token t = getNexttoken();
//		if (S(t))
//		{
//			token t = getNexttoken();
//			if (t.name == "else")
//			{
//				token t = getNexttoken();
//				if (S(t))return true;
//			}
//			else
//				return true;
//		}
//	}
//	else
//		return false;
//}
//bool whiles(token t)
//{
//	if (E(t))
//	{
//		token t = getNexttoken();
//		if (t.name != "do") return false;   //��while ��do
//		token t = getNexttoken();
//		if (!S(t))return false;
//		return true;
//	}
//	else    //��bool���
//	return false;
//}
//bool var(token t)
//{
//	if (D(t))
//	{
//		return true;
//	}
//	else return false;//��var��D
//}
//bool D(token t)
//{
//	if (L1(t))
//	{
//		token t = getNexttoken();
//		if (t.name != ":") return false;
//		token t = getNexttoken();
//		if (K(t))
//		{
//			token t = getNexttoken();
//			if (t.name != ";") return false;
//			token t = getNexttoken();
//			if (!D(t)) return true;
//			else {
//				setNexttoken(t.code);  ///
//				return true; 
//			}
//		}
//		else return false;
//	}
//	else return false;
//}
//bool L(token t)   //����
//{
//	if (!S(t)) return false;
//	token t = getNexttoken();
//	if (t.name == ";")
//	{
//		token t = getNexttoken();
//		if (L(t)) return true;
//		return false;
//	}
//	else
//	{
//		setNexttoken(t.code);
//		return  true;
//	}
//
//}
//bool L1(token t)
//{
//	if (t.name != "i") return false;
//	token t = getNexttoken();
//	if (t.name == ",")
//	{
//		token t = getNexttoken();
//		if (L1(t)) return true;
//		else return false;
//	}
//	else{
//		setNexttoken(t.code);
//		return true;
//	}
//}
//bool E(token t)
//{
//	if (t.name == "true") return true;
//	else if (t.name == "false") return true;
//	return false;
//}
//bool K(token t)
//{
//	if (t.name == "integer")
//		return true;
//	if (t.name == "real")
//		return true;
//	if (t.name == "bool")
//		return true;
//	return false;
//}